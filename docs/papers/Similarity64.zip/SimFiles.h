#pragma once
#include "definitions.h"

class SimFiles
{
public:
	SimFiles(void);
	~SimFiles(void);
	U32 doc1;
	U32 doc2;
	hashset intrhash;	//interesting shared kgrams
	hashset allhash;	//all shared kgrams
	int	intrsen;		//number of interesting sentences (that share interesting kgrams)
	int comsen;			//number of common sentences (that share only common kgrams)
	int dupfree1;		//largest duplicate-free part in doc1 - in number of sentences
	int dupfree2;		//largest duplicate-free part in doc2 - in number of sentences
	int filelen1;		//length of doc1 in sentences
	int filelen2;		//length of doc2 in sentences
	double gmean;		//median of percentages of dupfrees in respect to filelens
	int priority;		//influences sorting.
	string context;		//context for cross-mentioning authors
	bool onekgram;		//true if files share only 1 kgram
};

typedef vector<SimFiles> sfar;
