#include "StdAfx.h"
#include ".\sentinfo.h"

SentInfo::SentInfo(void):counter(0)
{
}

SentInfo::~SentInfo(void)
{
}

