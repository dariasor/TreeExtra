#include "StdAfx.h"
#include ".\simfiles.h"

SimFiles::SimFiles(void):filelen1(0),filelen2(0),dupfree1(0),dupfree2(0),priority(1),
intrsen(0),comsen(0)
{
}

SimFiles::~SimFiles(void)
{
}
