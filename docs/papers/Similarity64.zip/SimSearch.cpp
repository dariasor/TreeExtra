#include "StdAfx.h"
#include ".\simsearch.h"

#include <fstream>
#include <strstream>
#include <algorithm>
#include <windows.h>
#include <math.h>
#include "functions.h"
 

/*SimSearch::SimSearch()
{
	cout << "generate list of files\n";
	stringar fnames;
	processFiles(".",fnames);
	int i=0;
	for(stringar::iterator fnit = fnames.begin();fnit!=fnames.end();fnit++)
	{
		insertFile((*fnit).c_str(),i);
		i++;
		if(i%100 == 0)
			cout << *fnit << endl;
	}
}
*/ 
//upload documents into the system, each sentence in the infile is a path for some document
SimSearch::SimSearch(char* infile):kgramN(0)
{

	ofstream fwarn;
	fwarn.open(".\\similar\\warnings.html", ios_base::out);
	ofstream log;
	log.open("log.txt", ios_base::out);
	log.close();

	//read file deleted.txt, it contains names of files we need to ignore
	insertDelF();
	//read file collaborations.txt, fill collaborations
	insertColl();

	ifstream fin; //stream associated with the file
	fin.open(infile,ios_base::in);
	char buf[256];
	fin.getline(buf,256);
	int i=0;	//number of document
	while(fin.gcount())
	{//upload file with the name we just read from infile

		if(delFiles.find(psvToShort(buf)) != delFiles.end())
		{
			fin.getline(buf,256);//read the name of next document
			continue;
		}

		DocInfo di;//basic info about current document
		di.filename=buf;
		
		//upload names of authors
		stringv curAuths;//list of authors, may contain repetitions
		extrAuthor(psvToAbs(buf).c_str(),curAuths,collaborations);
		for(int auC=0;auC<(int)curAuths.size();auC++)
		{// upload name of author - both into the general table and 
		 // into the set of authors for the current document
			U64 ahash1 = fingerprint(simpleNm(curAuths[auC]));
			authors.insert(stringmap::value_type(ahash1,curAuths[auC]));
			di.authids.insert(hashset::value_type(ahash1));

			//update list of co-authors
			for(int auC2=0; auC2<(int)curAuths.size();auC2++)
			{
				U64 ahash2 = fingerprint(simpleNm(curAuths[auC2]));
				if(ahash1 < ahash2)
				{
					bighashsm::iterator hsmit= coauthors.find(ahash1);
					if(hsmit == coauthors.end())
					{
						hashset hs;
						hs.insert(hashset::value_type(ahash2));
						coauthors.insert(bighashsm::value_type(ahash1,hs));
					}
					else
						hsmit->second.insert(hashset::value_type(ahash2));
				}
			}
		}

		if(curAuths.size())
		{
			//upload information about the document and all its sentences
			filetbl.insert(docmap::value_type(i,di)); 
			int fileLen = insertFile(buf,i);
			if(fileLen < MINFILEL)
			{
				shortFiles.insert(i);

				fwarn << fnameToLink(buf) << "<br>" << endl;
				fwarn << "This document is too short and will not appear in the results.<br>"
					<< "It contains only " << fileLen << " sentences longer than " <<
					MINSENL -1 << " words. Possible conversion error.<br><br>"	<< endl;
			}
		}
		else
		{
			fwarn << fnameToLink(buf) << "<br>" << endl;
			fwarn << "No authors listed in abs file or the file is absent. This document was skipped.<br><br>"
				<< endl;
		}
		i++;
		if(i%100 == 0)
		{
			cout << buf << endl;
			if(i%1000 == 0)
			{
				ofstream log;
				log.open("log.txt",ios_base::app);
				log << buf << endl;
				log.close();
			}
		}

		fin.getline(buf,256);//read the name of next document
	}	
}

SimSearch::~SimSearch(void)
{
}

// inserts names of deleted files into delFiles
void SimSearch::insertDelF(const char* fname)
{
	ifstream fin; //stream associated with the file
	fin.open(fname,ios_base::in);
	char buf[256];
	fin.getline(buf,256);

	while(fin.gcount())
	{//upload the name of the file we just read into delFiles
		
		delFiles.insert(buf); 
		fin.getline(buf,256);//read the name of next document
	}	
}

// inserts names of collaborations into collaborations set
void SimSearch::insertColl(const char* fname)
{
	ifstream fin; //stream associated with the file
	fin.open(fname,ios_base::in);
	char buf[256];
	fin.getline(buf,256);

	while(fin.gcount())
	{//upload the name of the file we just read into delFiles
	
		collaborations.insert(buf); 
		fin.getline(buf,256);//read the name of next document
	}	
}

//inserts psv file (one sentence per line, only non-capital letters and spaces) into internal 
//structures 
//returns number of sentences with the length > MINSENL
int SimSearch::insertFile(const char* fname, U32 fid)
{
	char buf[256];//buffer to read data from file
	ifstream fin; //stream associated with the file
	string sequence;//current sequence
	string empty;//empty string
	inthashp curSen;//current kgram information block (Sen meant sentence in the original version, now it is kgram)
	curSen.first=fid;//will be the same for all sentences of this file
	int senN=0;//number of long sentences in the file

	fin.open(fname,ios_base::in);
	int wordN=0;

	fin.read(buf,256);
	bool newWord=false;
	while(fin.gcount())
	{   //process data from buf
		for(int c=0;c<fin.gcount();c++)
		{
		    //process character at buf[c]
//			sequence.push_back(buf[c]);
			sequence = sequence + buf[c];
			if(((buf[c]>='a')&&(buf[c]<='z'))||
			   ((buf[c]>='A')&&(buf[c]<='Z')))
				newWord=true;
			else
			{
				if(newWord)
				{
					wordN++;
					newWord=false;
				}
				if((buf[c]=='\n') && !sequence.empty())
				{//end of sentence, if it is long enough, get its kgrams 
					if(wordN >= MINSENL)
					{
						senN++;
						hashset kgramset = kgrams(sequence,wordN);
						kgramN += kgramset.size();
						
						//insert all kgrams from kgramset into table
						for(hashset::iterator kgit = kgramset.begin(); kgit != kgramset.end(); 
							kgit++)
						{
							curSen.second=*kgit;
							U32 key = (U32)(*kgit);
							table.insert(hashtable::value_type(key,curSen));
						}
					}
				
					sequence = empty;
					wordN=0;
				}
			}
		}//for
		fin.read(buf,256);
	}
	fin.close();

	return senN;
}

//outputs from the file all sentences larger then MINSENL
//highlights common (hashes2) and interesting (hashes1) duplicates
void SimSearch::outDupsFromFile(string fname, hashset& hashes1, hashset& hashes2, ofstream& fout)
{
	char buf[256];//buffer to read data from file
	ifstream fin; //stream associated with the file
	string realseq; //current sequence with spaces
	string empty;

	int wordN=0;
	bool newWord=false;

	fin.open(fname.c_str(),ios_base::in);
	fin.read(buf,256);
	while(fin.gcount())
	{   //process data from buf
		for(int c=0;c<fin.gcount();c++)
		{//process character at buf[c]
			realseq = realseq + buf[c];

			if((buf[c]>='a')&&(buf[c]<='z'))
				newWord=true;
			else 
			{
				if(newWord)
				{
					wordN++;
					newWord=false;
				}
				if(buf[c]=='\n')
				{
					//new sentence: check if it is a duplicate; output if yes; 
					if(wordN >= MINSENL)
					{
						colorSen(realseq,hashes1,hashes2,wordN);
						fout << realseq << endl;
					}
					wordN=0;
					
					realseq = empty;
				}
			}
		}//end of for(int c=0;c<fin.gcount();c++)
		fin.read(buf,256);
	}//end of while(fin.gcount())
}

//counts the largest part of the file that has no duplicates and length of file
void SimSearch::cntDupFree(string fname, hashset& hashes, int& maxnodup, int& filelen)
{
	int nodup = 0; //the length in sentences of current part without duplicates 

	hashset internal; //encountered duplicates are stored here; 
					  //every duplicate will be counted as dup-free delimeter only once

	char buf[256];//buffer to read data from file
	ifstream fin; //stream associated with the file
	string sequence;//current sequence
	string empty;
    
	int wordN=0;
	bool newWord=false;

	fin.open(fname.c_str(),ios_base::in);
	fin.read(buf,256);
	while(fin.gcount())
	{//process data from buf
		for(int c=0;c<fin.gcount();c++)
		{//process character at buf[c]
			
			sequence = sequence + buf[c];
			
			if((buf[c]>='a')&&(buf[c]<='z'))
				newWord=true;
			else 
			{
				if(newWord)
				{
					wordN++;
					newWord=false;
				}
				if((buf[c]=='\n') && (!sequence.empty()))
				{//new sentence
					if(wordN >= MINSENL)
					{//new sentence long enough: check if it is a valid new duplicate; 
						hashset kgramset = kgrams(sequence,wordN);
						if(intersect(kgramset,hashes))
						{//if duplicate is new, update nodup,maxnodup,filelen,internal
							if(!includes(internal,kgramset))
							{
								if(nodup > maxnodup)
									maxnodup=nodup;
								nodup=0;
								hashset::iterator ksi=kgramset.begin();
								for(; ksi != kgramset.end(); ksi++)
									internal.insert(*ksi);
							}
						}
						else
							nodup++;
						filelen++;
					}
					sequence = empty;
					wordN=0;
				}
			}
		}//end of for(int c=0;c<fin.gcount();c++)
		fin.read(buf,256);
	}//end of while(fin.gcount())
	if(nodup > maxnodup)
		maxnodup=nodup;
}

// outputs the content of the hash table. (just for testing on small amount of files)
/*string SimSearch::toString()
{
	string str="";
	char buf[256];
	hashtable::iterator it = table.begin();
	for(hashtable::iterator it = table.begin();it!=table.end();it++)
	{
		U32 hash1 = (U32)(it->second.hash/0x100000000);
		U32 hash2 = (U32)it->second.hash;

		sprintf(buf,"%d \t%d \t%x \t%x \t%x ",
					it->second.docId, it->second.wordN, it->first, hash1, hash2);

		str+=buf;
		str += "\n";
	}
	return str;
}
*/


// calculate and output common sentences
// fill docs (info about pairs of overlapping docs) from table
void SimSearch::outStat(/*ofstream& fout1, */ofstream& fout2, int& commonN)
{
	cout << "generating output" << endl;
	ofstream log;
	log.open("log.txt",ios_base::app);
	log << "\nNumber of k-grams in system: " << kgramN << "\n\n";
	log << "generating output" << endl;
	log.close();

	bool newkey=true;
	simap dups;	//for more detailed analysis of duplicates we will rewrite them 
				//in another map with whole hashes as keys

	siar common;// for most common kgrams

	for(hashtable::iterator it = table.begin();it!=table.end();it++)
	{
		hashtable::iterator next = it;
		next++;

		U64 hash = it->second.second;
		U32 docId = it->second.first;

		if(newkey)
		{
			if((next!=table.end()) && (next->first==it->first))
			{
				newkey=false;
				SentInfo si;
				si.docids.insert(docId);
				si.counter++;
				si.hash=hash;
				dups.insert(simap::value_type(hash,si));
			}
		}
		else
		{//newkey==false
			simap::iterator smit=dups.find(hash);
			if(smit==dups.end())//the kgram with such hash was not discovered yet
			{
				SentInfo si;
				si.hash=hash;
				si.docids.insert(docId);
				si.counter++;
				dups.insert(simap::value_type(hash,si));
			}
			else //dups.find(hash)!=dups.end()
			{
				smit->second.docids.insert(docId);
				smit->second.counter++;
			}
			if((next==table.end()) || (next->first!=it->first))
			{
				simap::iterator dupit;
				for(dupit=dups.begin();dupit != dups.end();dupit++)
				{
					SentInfo cursi = dupit->second;
					U64 hash = cursi.hash;
					int allDocN = (int)cursi.docids.size();
					int difDocN = nonInDifAu(cursi.docids);
					cursi.difAuN = difDocN;
					if(cursi.counter > 1)
					{
						if((difDocN >= MIN_COMMON_DIF) /*|| (difDocN>2) && 
							(allDocN >= MIN_COMMON_ALL)*/)
							common.push_back(cursi);
						else if(allDocN > 1) 
						{//update docs
							intset::iterator docit = cursi.docids.begin();
							for(;docit != cursi.docids.end();docit++)
							{
								if(shortFiles.find(*docit) != shortFiles.end())
									continue;

								intset::iterator docit2 = cursi.docids.begin(); 
								for(;docit2 != cursi.docids.end();docit2++)
									if((*docit<*docit2) 
										&& (shortFiles.find(*docit2) == shortFiles.end()))
									{	
										hashsmm::iterator dit = docs.find(*docit);
										if(dit != docs.end())
										{
											hashsm::iterator copyit = 
												dit->second.find(*docit2);
											if(copyit != dit->second.end())
												copyit->second.insert(hash);
											else
											{
												hashset hs;
												hs.insert(hash);
												dit->second.insert(hashsm::value_type
													(*docit2,hs));
											}
										}
										else
										{
											hashsm hsm;
											hashset hs;
											hs.insert(hash);
											hsm.insert(hashsm::value_type(*docit2,hs));
											docs.insert(hashsmm::value_type(*docit,hsm));
										}

									}//if(*docit<*docit2)
							}//for(;docit != cursi.docids.end();docit++)
						}//else if(allDocN > 1)
					}//if(cursi.counter > 1)
				}//	for(dupit=dups.begin();dupit != dups.end();dupit++)
				dups.clear();
				newkey=true;
			}//	if((next==table.end()) || (next->first!=it->first))
		}//else (newkey==false)
	}//for(hashtable::iterator it = table.begin();it!=table.end();it++)

	table.clear();
	siarSort(common);

	log.open("log.txt",ios_base::app);
	log << "most common kgrams" << endl;
	log.close();

	cout << "most common kgrams" << endl;
	
	fout2 << "Most common kgrams \ndif authors | dif docs | total \n\n";
		
	siar::iterator siarit=common.begin();
	int size = (int)common.size();
	for(int i=0;(siarit != common.end()) && (i < COMMON);siarit++)
	{
		if((i+1)%100 == 0)
		{
			cout << "\t" << i+1 << " out of " << size << endl;
			if((i+1)%1000 == 0)
			{
				ofstream log;
				log.open("log.txt",ios_base::app);
				log << "\t" << i+1 << " out of " << size << endl;
				log.close();
			}

		}

		string wholesen;
		fout2 << findSen(*(siarit->docids.begin()),siarit->hash,wholesen);
	
		int total = siarit->counter;
		int difA = siarit->difAuN;
		int difD = (int)siarit->docids.size();


		fout2 << "\nauthors: " << difA << " \tdocuments: " << difD << " \ttotal: "
			<< total << "\n" << /*wholesen << "\n" <<*/ endl;
		i++;
	}
	commonN = (int)common.size();
}

// outputs info about similar documents in fout and in separate file for each pair
void SimSearch::outSimFiles(int& sameN, int& pureN, int& commentN, bool outHTML)
{
	cout << "similar files" << endl << "\tfind all similar pairs" << endl;
	ofstream log;
	log.open("log.txt",ios_base::app);
	log << "similar files" << endl << "\tfind all similar pairs" << endl;
	log.close();

	//find most similar documents
	sfar alldocpairs;
	for(hashsmm::iterator dit = docs.begin();dit != docs.end();dit++)
	{
		docs.erase(docs.begin(),dit);
		for(hashsm::iterator copyit = dit->second.begin(); copyit != dit->second.end();copyit++)
		{
			//get names of files in this pair
	        if((copyit->second).size() >= MIN_DUPS)
			{
				SimFiles sf;
				sf.doc1 = dit->first;
				sf.doc2 = copyit->first;
				sf.intrhash = copyit->second;
				alldocpairs.push_back(sf);
			}
		}
	}

	docs.clear();
	cout << "\tcount dupfree & other features" << endl;
	log.open("log.txt",ios_base::app);
	log << "\nNumber of doc pairs in system: " << alldocpairs.size() << "\n\n";
	log << "\tcount dupfree & other features" << endl;
	log.close();

	sfar sameau,difau; //similar files written by same and different authors

	int size = (int)alldocpairs.size();
	int c=0;
	pureN=0;//number of pairs in difau without comments

	coauFP=0;	//number of pairs thrown away by coauthor heuristic
	collFP=0;	// ..collaboration..
	mentFP=0;	// ..mentioned..
	refFP=0;	// ..referenced..
	mcFP=0;		// ..both mentioned and collaboration..
	switchFP=0; // ..switched first and last name...

	intset pureset, commset, difset, dupset;

	int difNN = 0;
	int sameNN = 0;
	for(sfar::iterator sfit = alldocpairs.begin(); sfit != alldocpairs.end(); sfit++)
	{
		c++;
		if(c%100 == 0)
		{
			cout << "\t\t" << c << " out of " << size << endl;
			if(c%1000 == 0)
			{
				ofstream log;
				log.open("log.txt",ios_base::app);
				log << "\t\t" << c << " out of " << size << endl;
				log.close();
			}
		}
		//get names of files in this pair
		DocInfo file1,file2; //filenames
		file1 = filetbl.find(sfit->doc1)->second;
		file2 = filetbl.find(sfit->doc2)->second;
/*
		findAllDup(*sfit);
		if(sfit->intrsen >= MIN_DUPS )
	        if(!intersect(file1.authids,file2.authids))
				difNN++;
			else
				sameNN++;
*/
		
		//put corresponding pairs in sameau and difau
        if(!intersect(file1.authids,file2.authids))
		{//files of different authors
			//recalculate duplicates of this 2 files, now no duplicate is omitted

			findAllDup(*sfit);

			if(sfit->intrsen >= MIN_DUPS )
			{
				difNN++;
				bool switched=false;
				bool mention=false;
				bool ref=false;
				bool jointPaper=false;
				bool collAuthor=false;

				//if first and last names are swithed in one of abstracts
				if(checkSwitch(psvToAbs(file1.filename).c_str(),file2.authids) || 
					checkSwitch(psvToAbs(file2.filename).c_str(),file1.authids))
					switched=true;
				//if author of one paper was mentioned in the other paper
				for(hashset::iterator ait1=file1.authids.begin(); ait1!=file1.authids.end();ait1++)
				{
					if(findWord(file2.filename.c_str(),*ait1,sfit->context))
					{
						mention=true;
						continue;
					}
					string refname = file2.filename.substr(0, file2.filename.size()-3 ) + "ref";
					string stub;
					if(findWord(refname.c_str(),*ait1,stub))
					{
						ref = true;
						continue;
					}
				}
				if(!mention)
					for(hashset::iterator ait2=file2.authids.begin(); ait2!=file2.authids.end();ait2++)
					{
						if(findWord(file1.filename.c_str(),*ait2,sfit->context))
						{
							mention=true;
							continue;
						}
						string refname = file1.filename.substr(0, file1.filename.size()-3 ) + "ref";
						string stub;
						if(findWord(refname.c_str(),*ait2,stub))
						{
							ref = true;
							continue;
						}
					}
				//if authors collaborated in past
				if(collaborate(file1.authids,file2.authids))
					jointPaper=true;
				
				//if there is a collaboration listed as author
				if(isCollaboration(file1.authids) || isCollaboration(file2.authids))
					collAuthor = true;

				//set priority encoding type of comments
				if(mention)
					sfit->priority+=4;
				if(collAuthor)
					sfit->priority+=2;
				if(ref)
					sfit->priority+=1;

				//part about collecting statistics of interest
				if(switched)
					switchFP++;
				if(jointPaper)
					coauFP++;
				if (mention && collAuthor)
					mcFP++;
				if(mention)
					mentFP++;
				if(collAuthor)
					collFP++;
				if(ref)
					refFP++;
				
				if(!jointPaper && !switched && !(mention && collAuthor))
				{
					if(sfit->priority==1)
					{
						pureN++;
						purestat.push_back(sfit->intrsen);
						pureset.insert(sfit->doc1);
						pureset.insert(sfit->doc2);
					}
					else
					{
						commstat.push_back(sfit->intrsen);
						commset.insert(sfit->doc1);
						commset.insert(sfit->doc2);
					}

						difset.insert(sfit->doc1);
						difset.insert(sfit->doc2);

						difau.push_back(*sfit);
				}
			}
		}
 		else if(outHTML)
		{//files of same authors
/*			//recalculate duplicates of this 2 files, now no duplicate is omitted
			findAllDup(*sfit);
			//count largest dupfree parts of files
			cntDupFree(file1.filename,sfit->allhash,sfit->dupfree1,sfit->filelen1);
			cntDupFree(file2.filename,sfit->allhash,sfit->dupfree2,sfit->filelen2);
			sfit->gmean = sqrt((double)sfit->dupfree1/sfit->filelen1*sfit->dupfree2/sfit->filelen2);
			
			double orig1 = (double)sfit->dupfree1/sfit->filelen1;
			double orig2 = (double)sfit->dupfree2/sfit->filelen2;
			if((orig1 <= MAX_DUPFREE) || (orig2 <= MAX_DUPFREE))
			{
				sameau.push_back(*sfit);
		
				if(orig1 <= orig2)
					dupset.insert(sfit->doc1);
				else
					dupset.insert(sfit->doc2);
			}

			if((orig1 <= MAX_DUPFREE+0.2) || (orig2 <= MAX_DUPFREE+0.2))
				samestat.push_back(doublepv::value_type(min(orig1,orig2),max(orig1,orig2)));
*/		}
	}
	cout << "\tsort " << endl;
	log.open("log.txt",ios_base::app);
	log << "\nNumber of difau files before heuristics: " << difNN;
	log << "\nNumber of sameau files before heuristics: " << sameNN;
	log << "\nNumber of overall files before heuristics: " << difNN+sameNN;
/*	log << "\n\nNumber of unique files in pure list: " << pureset.size();
	log << "\nNumber of unique files in dif lists: " << difset.size();
	log << "\nNumber of duplicates: " << dupset.size();
*/	log << "\n\n\n\tsort " << endl;
	log.close();

/*
	//sort by max number of interesting duplicates
	sfarSortDupNum(difau);

	//sort by geometric mean of dup-free parts
	sfarSortDupFree(sameau);

	sort(purestat.begin(),purestat.end());
	sort(commstat.begin(),commstat.end());
	sort(samestat.begin(),samestat.end());

	cout << "\toutput duplicates in similar files" << endl;
	log.open("log.txt",ios_base::app);
	log << "\toutput duplicates in similar files" << endl;
	log.close();

	
	log.open("log.txt",ios_base::app);
	log << "\t\toutput duplicates in different author files" << endl;
	log.close();

	outDifFiles(difau, outHTML);

	log.open("log.txt",ios_base::app);
	log << "\t\toutput duplicates in same author files" << endl;
	log.close();

	if(outHTML)
		outSameFiles(sameau);

	log.open("log.txt",ios_base::app);
	log << "\t\t...Done" << endl;
	log.close();


*/	sameN = (int)sameau.size();
	commentN = (int)difau.size()-pureN;

}

//is called from outSimFiles - outputs similar files for same authors
void SimSearch::outSameFiles(sfar& docpairs)
{
	ofstream fout;

	string prefix = "same";

	int size = (int)docpairs.size();
	int pairNum=1;
	sfar::iterator sfit = docpairs.begin();
	for(int pageNum = 1; sfit != docpairs.end(); pageNum++)
	{
		//create new page for summary output 
		ofstream fout; //stream for this file 
		char buf[256]; //buf for the name (the whole path)for this file
		sprintf(buf,".\\similar\\%s%d.html",prefix.c_str(),pairNum);
		fout.open(buf,ios_base::out);

		fout << "<a href = \"index.html\">Back to main page<a><br><br>" << endl;
		if(pageNum != 1)
			fout << "<a href = \"" << prefix << pairNum - PAGE_LEN 
				<< ".html\">Back to previous page<a><br><br>" << endl;

		bool flagFirst=true;
		for(;(sfit != docpairs.end()) && (((pairNum-1) % PAGE_LEN != 0) || flagFirst); sfit++)
		{
			flagFirst=false;
			if(pairNum%100 == 1)
			{
				cout << "\t\t" << prefix << " " << pairNum << " out of " << size << endl;
				if(pairNum%1000 == 1)
				{
					ofstream log;
					log.open("log.txt",ios_base::app);
					log << "\t\t" << prefix << " " << pairNum << " out of " << size << endl;
					log.close();
				}
			}
			//get info of files in this pair
			DocInfo& file1 = filetbl.find(sfit->doc1)->second;
			DocInfo& file2 = filetbl.find(sfit->doc2)->second;
	        
			//create new file for detailed output about this pair
			ofstream fsim; //stream for this file 
			char buf[256]; //buf for the name (the whole path)for this file
			char bufsmall[256]; //buf just for the name of the file
			sprintf(buf,".\\similar\\%ssim%d.html",prefix.c_str(),pairNum);
			sprintf(bufsmall,"%ssim%d.html",prefix.c_str(),pairNum);
			fsim.open(buf,ios_base::out);
			string fsimname(bufsmall);

			//output back link into fsim
			fsim << "<a href = \"simfiles1.html\">Back to same authors page<a><br><br>" << endl;

			//output general info into both fout and fsim
			fout << "Pair " << pairNum << ":<br>" << fnameToLink(file1.filename).c_str() << "<br>\nAuthors: "; 
			for(hashset::iterator auit=file1.authids.begin();auit!=file1.authids.end();auit++)
				fout << authors.find(*auit)->second << ";  ";
			fout << "<br>" << endl;
			fout << fnameToLink(file2.filename).c_str() << "<br>\nAuthors: "; 
			for(hashset::iterator auit=file2.authids.begin();auit!=file2.authids.end();auit++)
				fout << authors.find(*auit)->second << ";  ";
			fout << "<br>" << endl;

			int intrstd = sfit->intrsen;
			fout << intrstd << " interesting duplicates<br>" << endl;

			int overalld = sfit->intrsen + sfit->comsen;
			fout << overalld << " overall duplicates<br>" << endl;
		
			// output info about largest dup-free part of file1 into both fout and fsim
			double nodup1 = (double)sfit->dupfree1/sfit->filelen1*100;
			fout << "dup-free 1 is " << nodup1 << " %&nbsp;&nbsp;&nbsp;&nbsp;(" << sfit->dupfree1 
				<< " / "  << sfit->filelen1 << ")<br>" << endl;

			// output info about largest dup-free part of file2 into both fout and fsim
			double nodup2 = (double)sfit->dupfree2/sfit->filelen2*100;
			fout << "dup-free 2 is " << nodup2 << " %&nbsp;&nbsp;&nbsp;&nbsp;(" << sfit->dupfree2 
				<< " / " << sfit->filelen2 << ")<br>\ngeometric mean " << sfit->gmean*100 << "<br>\n" 
				<< endl;

			//make a link from fout file to fsim file
			fout << "<a href=" << fsimname << ">details</a><br><br><br>" << endl;


			// output duplicates from file1 into fsim; 
			fsim << "<font color=red>red</font> - interesting kgrams, <font color=magenta>magenta</font> - common kgrams, <font color=green>green</font> - interesting sentences, <font color=blue>blue</font> - common sentences, <font color=black>black</font> - non-duplicates<br>\n<table><tr><td width=50%></td>\n<td width=50%></td></tr>\n<tr><td>" 
				<< fnameToLink(file1.filename).c_str() << "</td>" << endl;
			fsim << "<td>" << fnameToLink(file2.filename).c_str() << "</td></tr>\n<tr><td valign=top>" << endl;
			outDupsFromFile(file1.filename,sfit->intrhash,sfit->allhash,fsim);
			fsim << "</td>\n<td valign=top>" << endl;

			// output duplicates from file2 into fsim; 
			outDupsFromFile(file2.filename,sfit->intrhash,sfit->allhash,fsim);
			fsim << "</td></tr></table>\n";

			fsim.close();

			pairNum++;
		}

		if(sfit != docpairs.end())
			fout << "<a href = \"" << prefix << pairNum  
				<< ".html\">Next page<a><br><br>" << endl;
		fout.close();
	}
}

//outputs one file for pair comparison
void SimSearch::outPair(SimFiles* sfpair, ofstream& fsim, int type)
{
	DocInfo& file1 = filetbl.find(sfpair->doc1)->second;
	DocInfo& file2 = filetbl.find(sfpair->doc2)->second;

	//output back link into fsim
	fsim << "<a href = \"simfiles" << type 
		<< ".html\">Back to different authors page<a><br><br>" << endl;

	//output duplicates from file1 into fsim; 
	fsim << "<font color=red>red</font> - interesting kgrams, <font color=magenta>magenta</font> - common kgrams, <font color=green>green</font> - interesting sentences, <font color=blue>blue</font> - common sentences, <font color=black>black</font> - non-duplicates<br>\n<table><tr><td width=50%></td>\n<td width=50%></td></tr>\n<tr><td>" 
		<< fnameToLink(file1.filename).c_str() << "</td>\n" << endl;
	fsim << "<td>" << fnameToLink(file2.filename).c_str() << "</td></tr>\n<tr><td valign=top>" << endl;
	outDupsFromFile(file1.filename,sfpair->intrhash,sfpair->allhash,fsim);
	fsim << "</td>\n<td valign=top>" << endl;

	// output duplicates from file2 into fsim; 
	outDupsFromFile(file2.filename,sfpair->intrhash,sfpair->allhash,fsim);
	fsim << "</td></tr></table>\n";

	fsim.close();
}

//is called from outSimFiles - outputs similar files for different authors
//output of graphs structure happens in this function
void SimSearch::outDifFiles(sfar& docpairs, bool outHTML)
{
	//open .dot file, write down the header
	ofstream fgraph;
	fgraph.open(".\\similar\\overlaps.dot",ios_base::out);
	fgraph << "graph Overlaps {\n\tedge [style=bold];\n";

	stringset allNodes, dupNodes; //structures that should help leave only interesting subgraphs
	stringv edges; //edges lines in graph file

	//output pure pairs
	string prefix="pure";
	int size = (int)docpairs.size();

	int pairNum=1;
	sfar::iterator sfit = docpairs.begin();
	for(int pageNum = 1; (sfit != docpairs.end()) && (sfit->priority == 1); pageNum++)
	{
		//create new page for summary output 
		ofstream foutpure; //stream for this file 
		char buf[256]; //buf for the name (the whole path)for this file
		sprintf(buf,".\\similar\\%s%d.html",prefix.c_str(),pairNum);
		foutpure.open(buf,ios_base::out);

		foutpure << "<a href = \"index.html\">Back to main page<a><br><br>" << endl;
		if(pageNum != 1)
			foutpure << "<a href = \"" << prefix << pairNum - PAGE_LEN 
				<< ".html\">Back to previous page<a><br><br>" << endl;

		bool flagFirst=true;
		for(; (sfit != docpairs.end()) && (sfit->priority == 1) 
			   && (((pairNum-1) % PAGE_LEN != 0) || flagFirst); sfit++)
		{
			flagFirst = false;
			if(pairNum%100 == 1)
			{
				cout << "\t\t" << prefix << " " << pairNum << " out of " << size << endl;
				if(pairNum%1000 == 1)
				{
					ofstream log;
					log.open("log.txt",ios_base::app);
					log << "\t\t" << prefix << " " << pairNum << " out of " << size << endl;
					log.close();
				}
			}
			//get info of files in this pair
			DocInfo& file1 = filetbl.find(sfit->doc1)->second;
			DocInfo& file2 = filetbl.find(sfit->doc2)->second;

			//output number of pair
			foutpure << "Pair "<< pairNum << ":<br>" << endl;

			
			//create new file for detailed output about this pair
			ofstream fsim; //stream for this file 
			char buf[256]; //buf for the name (the whold path)for this file
			char bufsmall[256]; //buf just for the name of the file
			sprintf(buf,".\\similar\\%ssim%d.html",prefix.c_str(),pairNum);
			sprintf(bufsmall,"%ssim%d.html",prefix.c_str(),pairNum);
			if(outHTML)
				fsim.open(buf,ios_base::out);
			string fsimname(bufsmall);

			//output general info into fout 
			foutpure << fnameToLink(file1.filename).c_str() << "<br>\nAuthors: "; 
			for(hashset::iterator auit=file1.authids.begin();auit!=file1.authids.end();auit++)
				foutpure << authors.find(*auit)->second << ";  ";
			foutpure << "<br>" << endl;
			foutpure << fnameToLink(file2.filename).c_str() << "<br>\nAuthors: "; 
			for(hashset::iterator auit=file2.authids.begin();auit!=file2.authids.end();auit++)
				foutpure << authors.find(*auit)->second << ";  ";
			foutpure << "<br>" << endl;

			int intrstd = sfit->intrsen;
			foutpure << intrstd << " interesting duplicates<br>" << endl;

			int overalld = sfit->comsen + sfit->intrsen;
			foutpure << overalld << " overall duplicates<br>" << endl;
		
			//make a link from fout file to fsim file
			foutpure << "<a href=" << fsimname << ">details</a><br><br><br>" << endl;
		
			if(outHTML)
				outPair(&(*sfit), fsim, 2);

			fsim.close();

			char pairNum_c[10], intrstd_c[10];
			itoa(pairNum,pairNum_c,10);
			itoa(intrstd, intrstd_c, 10);

			//create edge describing string
			string edgestr = "\t\"";
			edgestr += fnameToId(file1.filename);
			edgestr += "\" -- \"";
			edgestr += fnameToId(file2.filename);
			edgestr += "\" [color=red] [label = \"";
			edgestr += pairNum_c;
			edgestr += ": ";
			edgestr += intrstd_c;
			edgestr += "\" ];\n";


			//add this edge into the full graph file and save it
			fgraph << edgestr;
			edges.push_back(edgestr);

			//save info for the construction of interesting graph
			if(allNodes.find(file1.filename) == allNodes.end())
				allNodes.insert(file1.filename);
			else
				dupNodes.insert(file1.filename);
			if(allNodes.find(file2.filename) == allNodes.end())
				allNodes.insert(file2.filename);
			else
				dupNodes.insert(file2.filename);


			pairNum++;
		}
		if((sfit != docpairs.end()) && (sfit->priority == 1))
			foutpure << "<a href = \"" << prefix << pairNum  
				<< ".html\">Next page<a><br><br>" << endl;
		foutpure.close();
	}

	//output commented pairs
	prefix="comm";
	pairNum=1;
	for(int pageNum = 1; (sfit != docpairs.end()); pageNum++)
	{
		//create new page for summary output 
		ofstream foutcomm; //stream for this file 
		char buf[256]; //buf for the name (the whole path)for this file
		sprintf(buf,".\\similar\\%s%d.html",prefix.c_str(),pairNum);
		foutcomm.open(buf,ios_base::out);

		foutcomm << "<a href = \"index.html\">Back to main page<a><br><br>" << endl;
		if(pageNum != 1)
			foutcomm << "<a href = \"" << prefix << pairNum - PAGE_LEN 
				<< ".html\">Back to previous page<a><br><br>" << endl;

		bool flagFirst=true;
		for(; (sfit != docpairs.end()) && (((pairNum-1) % PAGE_LEN != 0) || flagFirst); sfit++)
		{
			flagFirst = false;

			if(pairNum%100 == 1)
			{
				cout << "\t\t" << prefix << " " << pairNum << " out of " << size << endl;
				if(pairNum%1000 == 1)
				{
					ofstream log;
					log.open("log.txt",ios_base::app);
					log << "\t\t" << prefix << " " << pairNum << " out of " << size << endl;
					log.close();
				}
			}
			//get info of files in this pair
			DocInfo& file1 = filetbl.find(sfit->doc1)->second;
			DocInfo& file2 = filetbl.find(sfit->doc2)->second;

			//output number of pair
			foutcomm << "Pair "<< pairNum << ":<br>" << endl;

			//output warnings if needed
			int priority = sfit->priority-1;
			
			if(priority/8 == 1)
			{
				ofstream fwarn;
				fwarn.open(".\\similar\\warnings.html", ios_base::app);
				fwarn << fnameToLink(file1.filename) << "<br>" << endl;
				fwarn << fnameToLink(file2.filename) << "<br>" << endl;
				fwarn << "High chance of switched first and last names in one of abstracts " << 
						"for these files.<br><br>" << endl;
				foutcomm << "Warning: High chance of switched first and last names in one of abstracts " << 
						"for these files.<br>" << endl;
				
				priority -= 8;
			}
			if(priority/4==1)
			{
				foutcomm << "Comment: Author of one of these papers is mentioned in the other one " 
					<< "in the following context:<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>" 
					<< "<font color=\"brown\">" << sfit->context << "</font></i><br>" << endl;
				priority -= 4;
			}
			if(priority/2==1)
			{
				foutcomm << "Comment: set of authors includes collaboration.<br>" << endl;
				priority -= 2;
			}
			if(priority == 1)
				foutcomm << "Comment: one of the papers references an author of the other<br>" << endl;

	        
			//create new file for detailed output about this pair
			ofstream fsim; //stream for this file 
			char buf[256]; //buf for the name (the whold path)for this file
			char bufsmall[256]; //buf just for the name of the file
			sprintf(buf,".\\similar\\%ssim%d.html",prefix.c_str(),pairNum);
			sprintf(bufsmall,"%ssim%d.html",prefix.c_str(),pairNum);
			if(outHTML)
				fsim.open(buf,ios_base::out);
			string fsimname(bufsmall);

			//output general info into fout 
			foutcomm << fnameToLink(file1.filename).c_str() << "<br>\nAuthors: "; 
			for(hashset::iterator auit=file1.authids.begin();auit!=file1.authids.end();auit++)
				foutcomm << authors.find(*auit)->second << ";  ";
			foutcomm << "<br>" << endl;
			foutcomm << fnameToLink(file2.filename).c_str() << "<br>\nAuthors: "; 
			for(hashset::iterator auit=file2.authids.begin();auit!=file2.authids.end();auit++)
				foutcomm << authors.find(*auit)->second << ";  ";
			foutcomm << "<br>" << endl;

			int intrstd = sfit->intrsen;
			foutcomm << intrstd << " interesting duplicates<br>" << endl;

			int overalld = sfit->comsen + sfit->intrsen;
			foutcomm << overalld << " overall duplicates<br>" << endl;
		
			//make a link from fout file to fsim file
			foutcomm << "<a href=" << fsimname << ">details</a><br><br><br>" << endl;
		
			if(outHTML)
				outPair(&(*sfit), fsim, 3);

			fsim.close();

			//create edge describing string
			char pairNum_c[10], intrstd_c[10];
			itoa(pairNum,pairNum_c,10);
			itoa(intrstd, intrstd_c, 10);

			string edgestr = "\t\"";
			edgestr += fnameToId(file1.filename);
			edgestr += "\" -- \"";
			edgestr += fnameToId(file2.filename);
			edgestr += "\" [color=blue] [label = \"";
			edgestr += pairNum_c;
			edgestr += ": ";
			edgestr += intrstd_c;
			edgestr += "\" ];\n";

			//add this edge into the full graph file and save it
			fgraph << edgestr;
			edges.push_back(edgestr);

			//save info for the construction of interesting graph
			if(allNodes.find(file1.filename) == allNodes.end())
				allNodes.insert(file1.filename);
			else
				dupNodes.insert(file1.filename);
			if(allNodes.find(file2.filename) == allNodes.end())
				allNodes.insert(file2.filename);
			else
				dupNodes.insert(file2.filename);


			pairNum++;
		}

		if(sfit != docpairs.end())
			foutcomm << "<a href = \"" << prefix << pairNum  
				<< ".html\">Next page<a><br><br>" << endl;
		foutcomm.close();
	}

	fgraph << "}";
	fgraph.close();

	//create small graph including only components larger than 2 nodes
	ofstream fsmgraph;
	fsmgraph.open(".\\similar\\overlaps2.dot",ios_base::out);
	fsmgraph << "graph Interesting_Overlaps {\n\tedge [style=bold];\n";

	for(int edgeNum = 0; edgeNum < (int)edges.size(); edgeNum++)
	{
		//get info of files in this pair
		string fname1 = filetbl.find(docpairs[edgeNum].doc1)->second.filename;
		string fname2 = filetbl.find(docpairs[edgeNum].doc2)->second.filename;

		if((dupNodes.find(fname1) != dupNodes.end()) || 
			(dupNodes.find(fname2) != dupNodes.end()))
			fsmgraph << edges[edgeNum];
	}
	
	fsmgraph << "}";
	fsmgraph.close();
	
}

//finds a kgram from file fid that was converted into the given (hash) fingerprint
//returns the whole sentence containing this kgram in wholesen
string SimSearch::findSen(U32 fid, U64 hash, string& wholesen)
{
	string fnamestr = filetbl.find(fid)->second.filename;
	
	char* fname = (char*)fnamestr.c_str();

	char buf[256];//buffer to read data from file
	ifstream fin; //stream associated with the file
	string realseq; //current sequence with spaces
	string empty;

	fin.open(fname,ios_base::in);
	int wordN=0;

	fin.read(buf,256);
	bool newWord=false;
	while(fin.gcount())
	{   //process data from buf
		for(int c=0;c<fin.gcount();c++)
		{
		    //process character at buf[c]
			realseq = realseq + buf[c];

			if((buf[c]>='a')&&(buf[c]<='z'))
				newWord=true;
			else
			{
                if(newWord)
				{
					wordN++;
					newWord=false;
				}
				if(buf[c]=='\n')
				{
					if(wordN >= MINSENL)
					{
						hashset kgramset = kgrams(realseq, wordN);
						if(kgramset.find(hash) != kgramset.end())
						{
							wholesen=realseq;
							return findKGram(realseq, hash);
						}
					}
					realseq = empty;
					wordN=0;
				}
			}//else
		}//for
		fin.read(buf,256);
	}

	return "";//never to be reached
}

//true if there is such word in this file
bool SimSearch::findWord(const char* fname, U64 hash, string& context)
{
	char buf[256];//buffer to read data from file
	ifstream fin; //stream associated with the file

	string word;

	string sequence;//current sequence
	string previous;
	string prev2;

	string empty;

	bool foundWrd = false;
	bool foundSen = false;

	fin.open(fname,ios_base::in);
	fin.read(buf,256);
	while(fin.gcount())
	{   //process data from buf
		for(int c=0;c<fin.gcount();c++)
		{
		    //process character at buf[c]
			if(((buf[c]>='a')&&(buf[c]<='z'))||
			   ((buf[c]>='A')&&(buf[c]<='Z')))
			{
				word = word + buf[c];
				sequence = sequence + buf[c];
			}
			else 
			{
				if(!word.empty())
				{
					if(fingerprint(simpleNm(word))==hash)
						foundWrd=true;
					
					sequence = sequence + buf[c];
					word = empty;
				}

				if((buf[c]=='\n') && (sequence != empty))
				{
					if(foundSen)
					{
						context=prev2 + ". <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp ";
						context+=previous + ". <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp ";
						context+=sequence + ".";
						return true;
					}
					if(foundWrd)
						foundSen=true;

					prev2=previous;
					previous=sequence;
					sequence = empty;
				}
			}
		}//for
		fin.read(buf,256);
	}
	return false;
}

//find all cross-document duplicates (both interesting and not interesting)in two files;
//fill sf.allhash
void SimSearch::findAllDup(SimFiles& sf)
{
	const char* file1 = filetbl.find(sf.doc1)->second.filename.c_str();
	const char* file2 = filetbl.find(sf.doc2)->second.filename.c_str();

	hashset temp; // to store all hashes from the first file
	char buf[256];//buffer to read data 
	ifstream fin1; //stream associated with the file
	string sequence;//current sequence
	string empty;

	int wordN=0;
	bool newWord=false;
	//insert all hashes from the first file into temp
	fin1.open(file1,ios_base::in);
	fin1.read(buf,256);
	while(fin1.gcount())
	{   //process data from buf
		for(int c=0;c<fin1.gcount();c++)
		{
			sequence += buf[c];
			if(((buf[c]>='a')&&(buf[c]<='z'))||
			   ((buf[c]>='A')&&(buf[c]<='Z')))
				newWord=true;
			else 
			{
				if(newWord)
				{
					wordN++;
					newWord=false;
				}
				if(buf[c]=='\n')
				{
					if(wordN >= MINSENL)
					{
						hashset kgramset = kgrams(sequence,wordN);
						for(hashset::iterator kgit = kgramset.begin(); kgit != kgramset.end(); 
							kgit++)
							temp.insert(*kgit);
					}
					sequence = empty;
					wordN=0;
				}
			}
		}//for
		fin1.read(buf,256);
	}

	//insert into sf.allhash those hashes from the second file that are already in temp
	ifstream fin2;
	fin2.open(file2,ios_base::in);
	fin2.read(buf,256);
	wordN=0;
	newWord=false;
	
	hashset tempforsen; //this temp hashset is used to count the number of sentences 
						//(to eliminated kgrams that happen several times in one document)

	while(fin2.gcount())
	{//process data from buf
		for(int c=0;c<fin2.gcount();c++)
		{
			sequence += buf[c];

			if(((buf[c]>='a')&&(buf[c]<='z'))||
			   ((buf[c]>='A')&&(buf[c]<='Z')))
				newWord=true;
			else
			{
				if(newWord)
				{
					wordN++;
					newWord=false;
				}
				if((buf[c]=='\n') && !sequence.empty())
				{
					if(wordN >= MINSENL)
					{
						hashset kgramset = kgrams(sequence,wordN);
						bool newcom = false;//new common sentence
						bool newintr = false;//new interesting sentence

						//check every kgram of the sentence
						for(hashset::iterator kgit = kgramset.begin(); kgit != kgramset.end(); 
							kgit++)
							if(temp.find(*kgit) != temp.end())
							{//this is a shared kgram
								sf.allhash.insert(*kgit); //insert it to all shared kgrams
								if(tempforsen.find(*kgit) == tempforsen.end())
								{//we have not counted it yet
									tempforsen.insert(*kgit);//insert to observed kgrams of this docpair
									//the kgram witnesses either for interesting or common sentence
									if(sf.intrhash.find(*kgit) != sf.intrhash.end())
										newintr = true;
									else 
										newcom = true;
								}
							}
						if(newintr)
							sf.intrsen++;
						else if(newcom)
							sf.comsen++;
					}
					sequence=empty;
					wordN=0;
				}
			}
		}//for
		fin2.read(buf,256);
	}
}

// returns how many files with different authors docids contain. 
// sometimes can return a smaller value (if it finds not the largest possible subset), 
// but for our purposes it is not a big deal
int SimSearch::nonInDifAu(intset& docids)
{
	docv difdocs;
	for(intset::iterator docit = docids.begin(); docit!=docids.end(); docit++)
	{
		DocInfo& doc1 = filetbl.find(*docit)->second;
		bool intersct=false;
		for(docv::iterator ddit = difdocs.begin();ddit!=difdocs.end();ddit++)
			if(intersect(doc1.authids,ddit->authids))
			{
				intersct=true;
				break;
			}

		if(!intersct)
			difdocs.push_back(doc1);
	}
	return (int)difdocs.size();
}

// true, if someone from the first set collaborated with someone from the second set
bool SimSearch::collaborate(hashset& authors1, hashset& authors2)
{
	for(hashset::iterator ait1 = authors1.begin(); ait1!=authors1.end();ait1++)
		for(hashset::iterator ait2 = authors2.begin(); ait2!=authors2.end();ait2++)
			if(*ait1 != *ait2)
			{
				bighashsm::iterator coll1it = coauthors.find(*ait1);
				if(coll1it != coauthors.end())
				{
					hashset& coll1 = coll1it->second;
					if(coll1.find(*ait2) != coll1.end())
						return true;
				}
				
				bighashsm::iterator coll2it = coauthors.find(*ait2);
				if(coll2it != coauthors.end())
				{
					hashset& coll2 = coll2it->second;
					if(coll2.find(*ait1) != coll2.end())
						return true;
				}
			}
	return false;
}

bool SimSearch::isCollaboration(hashset& authids)
{
	for(hashset::iterator auIt = authids.begin(); auIt != authids.end(); auIt++)
	{
		string str = authors.find(*auIt)->second;
		int n = (int)str.size();
		
		if(n<13)
			continue;

		str = str.substr(n-13,13);

		if(!str.compare("Collaboration"))
			return true;
	}
	return false;
}
