#pragma once
#include "SentInfo.h"
#include "SimFiles.h"
#include <fstream>

bool siGreater(SentInfo& si1, SentInfo& si2); 
void siarSort(siar& array);

bool sfLessDupFree(SimFiles& sf1, SimFiles& sf2); 
void sfarSortDupFree(sfar& array);
bool sfGreaterDupNum(SimFiles& sf1, SimFiles& sf2); 
void sfarSortDupNum(sfar& array);

// hash-function, from string to long
U64 fingerprint(string str);

// returns the number of symbol in the sequence a-z, i.e. a number between 1 and 26
int charToInt(char c);

//divide x by y and round correctly
int divround(int x, int y);

string U64toString(U64 hash);

//simplify the spelling of the name: 
//the goal is to converge different possible spellings of the same name to one
string simpleNm(string str);

//makes a list of files *.psv in all subdirectories;
void processFiles(const char *path_name, ofstream& fout);

//extracts last names of authors from .abs file 
void extrAuthor(const char* fname, stringv& authors, stringset& collaborations);

//called in extrAuthor before exit; cleans name list
void refineAuthors(stringv& authors);

//checks if anything in the authors part of .abs file belongs to authors 
//(probably there is a first name mistaken for last name)
bool checkSwitch(const char* fname, hashset& authors);

//psv path to abs path - only for current test set
string psvToAbs(string psvstr);

//return short encoding for arxiv file from the path to psv file
string psvToShort(string psvstr);

//true if intersection of 2 sets is not zero
bool intersect(hashset& set1, hashset& set2);

//true if set1 contains set2
bool includes(hashset& set1, hashset& set2);

//returns set of k-grams following Winnowing algorithm, but smallest item is word, not symbol
hashset kgrams(string& sentence, int length);

//finds part of sentence that was hashed in a given kgram(hash)
string findKGram(string& sentence, U64 hash);

//makes html output with hashes colored correctly
void colorSen(string& sentence, hashset& hashes1, hashset& hashes2, int wordN);

//converts file name to html link to arxive.org
string fnameToLink(string line);

//shortens file name to paper id
string fnameToId(string line);

//outputs heights of bars in one line, values of x in the other line
void outHist(ofstream& fout, intmap& hist);

//inserts new value into the map or increases existing value
void updateMap(intmap& m, int key, int add);

//join two maps: sum values of identical keys, add all other
intmap joinMaps(intmap& map1, intmap& map2);

//convert values from map into histogram
intmap mapToHist(intmap& m);