#pragma once
#include "definitions.h"

// the name of the class is obsolete - now it should have been called KGramInfo,
// because each instance of class refers to one kgram
class SentInfo
{
public:
	SentInfo(void);
	~SentInfo(void);

	int counter;
	int difAuN;
	intset docids;
	U64 hash;
};
//typedef hash_map<U64,SentInfo> simap;
typedef map<U64,SentInfo> simap;
typedef vector<SentInfo> siar;