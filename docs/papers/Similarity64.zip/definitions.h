#pragma once
#include <vector>
#include <string>
//#include <hash_set>
//#include <hash_map>
#include <set>
#include <map>


using namespace std;
//using namespace stdext;

typedef unsigned long long U64;
typedef unsigned int U32;
typedef unsigned short U16;
typedef unsigned char U8;

/*typedef hash_set<U32> intset;
typedef hash_set<U64> hashset;
typedef hash_map<U64,string> stringmap;
typedef hash_map<U32,hashset> hashsm;
typedef hash_map<U64,hashset> bighashsm;
typedef hash_map<U32,hashsm> hashsmm;
typedef vector<string> stringv;
typedef vector<U64> hashv;
typedef vector<int> intv;
typedef pair<U32,U64> inthashp;
typedef hash_multimap<U32,inthashp> hashtable;
!! also need to fix hash_map in sentinfo and docinfo
*/

typedef set<U32> intset;
typedef set<U64> hashset;
typedef set<string> stringset;

typedef map<U64,string> stringmap;
typedef map<string,string> strstrmap;
typedef map<U32,hashset> hashsm;
typedef map<U64,hashset> bighashsm;
typedef map<U32,hashsm> hashsmm;
typedef map<int,int> intmap;

typedef vector<string> stringv;
typedef vector<U64> hashv;
typedef vector<int> intv;

typedef pair<U32,U64> inthashp;
typedef multimap<U32,inthashp> hashtable;

typedef pair<double,double> doublep;
typedef vector<doublep> doublepv;

#define BASE 27 //amount of different symbols 
#define PRIME 682551457733942743	//large prime number that will not cause overflow 
									//in 64 bits variable when used for fingerprinting
									//(i.e. less than 683212743470724132)

#define MINSENL 7 //the shortest length of sentence we want to examine
#define MINFILEL 10 //the shortest number of big sentences in the file to concider it correct
//#define SENL 50	//the largest length of sentence we want to examine
#define COMMON 1000 //how many common sentences we want to view
#define MIN_COMMON_DIF 4 //minimum required number of docs of different author for the common sentence
#define MIN_COMMON_ALL 6 //alternative: minimum required overall number of docs for the common sentence 
#define MIN_DUPS 4 //how many interesting duplicates similar files have to share
#define MAX_DUPFREE 0.2 //how large the originality may be in 2 similar files of the same authors

//winnowing
#define WINK MINSENL
#define WINT 12

//output
#define PAGE_LEN 50 //how many results per page