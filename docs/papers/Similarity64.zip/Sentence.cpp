#include "StdAfx.h"
#include ".\sentence.h"

Sentence::Sentence(void)
{
}

Sentence::~Sentence(void)
{
}
