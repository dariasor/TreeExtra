#pragma once
#include "SentInfo.h"
#include "SimFiles.h"
#include "DocInfo.h"


class SimSearch
{
public:
	SimSearch(char* infile);//upload documents into the system, each sentence in the infile is a path for some document
	~SimSearch(void);
private:
	hashtable table;	//sentences
	docmap filetbl;		//id's and names of files
	stringmap authors;	//id's(hashes) and names of authors
	hashsmm docs;		//info about overlap of documents
	bighashsm coauthors;	//graph of collaborators
	stringset delFiles;	//names of files that should be ignored
	stringset collaborations; //names of collaborations that can appear in abs file
	intset	shortFiles;	//ids of short files (< MINFILEL sentences) that should not appear in the results 

public:
	//this set of variables is for collecting different data for the paper
	intv purestat;	//ordered overlap sizes in pure pairs
	intv commstat;	//ordered overlap sizes in commented pairs
	doublepv samestat;	//ordered min and max originality in same author pairs
	int coauFP;	//number of pairs thrown away by coauthor heuristic
	int collFP;	// ..collaboration..
	int mentFP;	// ..mentioned..
	int refFP;	// ..referenced..
	int mcFP;	// ..both mentioned and collaboration...
	int switchFP;	//..switched name..

	U64 kgramN; //number of kgrams

private:
	// inserts sentences from the file into the hash-table
	int insertFile(const char* fname, U32 fid);

	// inserts names of deleted files into delFiles
	void insertDelF(const char* fname="deleted.txt" );

	// inserts names of collaborations into collaborations set
	void insertColl(const char* fname="collaborations.txt" );

	//finds a kgram from file fid that was converted into the given (hash) fingerprint
	//returns the whole sentence containing this kgram in wholesen
	string SimSearch::findSen(U32 fid, U64 hash, string& wholesen);

	//finds all cross-document duplicates without any constraints in two files
	void findAllDup(SimFiles& sf);

	//counts the largest part of the file that has no duplicates and length of file
	void cntDupFree(string fname, hashset& hashes, int& maxnodup, int& filelen);

	//outputs from the file all sentences larger then MINSENL
	//highlights common (hashes2) and interesting (hashes1) duplicates
	void outDupsFromFile(string fname, hashset& hashes1, hashset& hashes2, ofstream& fout);

	//outputs one file for pair comparison
	void outPair(SimFiles* sfpair, ofstream& fsim, int type);

	// returns how many files with different authors docids contain. 
	// sometimes can return a smaller value (if it finds not the largest possible subset), 
	// but for our purposes it is not a big deal
	int nonInDifAu(intset& docids);

	//true if there is such word in this file
	bool findWord(const char* filename, U64 hash, string& context);

	//is called from outSimFiles
	void outSameFiles(sfar& docpairs);
	void outDifFiles(sfar& docpairs, bool outHTML);

	// true, if someone from the first set collaborated with someone from the second set
	bool collaborate(hashset& authors1, hashset& authors2);
	bool isCollaboration(hashset& authids);

public:
	// outputs the content of the hash table. (just for testing on small amount of files)
	string toString();
	// outputs /*statistics info*/ and most common sentences
	void outStat(/*ofstream& fout1, */ofstream& fout2, int& commonN);

	// outputs info about similar documents in fout and in separate file for each pair
	void outSimFiles(int& sameN, int& pureN, int& commentN, bool outHTML);
};
