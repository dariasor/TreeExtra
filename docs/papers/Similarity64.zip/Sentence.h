#pragma once
#include "definitions.h"

 
class Sentence
{
public:
	Sentence(void);
	~Sentence(void);
	U64 hash;
	U32 docId;
};

typedef hash_multimap<U32,Sentence> hashtable;
