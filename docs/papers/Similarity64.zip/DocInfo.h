#pragma once
#include "definitions.h"
class DocInfo
{
public:
	string filename;
	hashset authids;

	DocInfo(void);
	~DocInfo(void);
};
//typedef hash_map<U32,DocInfo> docmap;
typedef map<U32,DocInfo> docmap;
typedef vector<DocInfo> docv;