#include "StdAfx.h"
#include ".\functions.h"
#include <algorithm>
#include <windows.h>
#include <fstream>

// returns the number of symbol in the sequence a-z, i.e. a number between 1 and 26
int charToInt(char c)
{
	if((c>='a')&&(c<='z'))
		return 1 + c - 'a';
	if((c>='A')&&(c<='Z'))
		return 1+ c - 'A';

	return 0;
}

// hash-function, from string to U64. Only latin letters are taken into consideration
U64 fingerprint(string str)
{
	size_t n = str.length();
	U64 res = 0;
	for(size_t i = 0;i<n;i++)
	{
		if(int symbolcd = charToInt(str[i]))
			res = (res*BASE + symbolcd)%PRIME;
	}
	return res;
}

//simplify the spelling of the name: 
//the goal is to converge different possible spellings of the same name to one
string simpleNm(string str)
{
	for(int i=0;i<(int)str.size();i++)
		if((str[i]>='A')&&(str[i]<='Z'))
			str[i] = str[i] - 'A' + 'a';

	if((str[0] == 'd') && (str[1] == '\''))
		str = str.substr(2,str.size()-2); //ignore d' in the beginning of the name

	string res;
	bool wait=false;
	for(int i=0;i<(int)str.size();i++)
		if(wait)
		{
			if((str[i]=='e') && ((str[i-1]=='a')||(str[i-1]=='o')||(str[i-1]=='u')))//umlaut
			{
				res +=str[i-1];
				wait = false;
			}
			else if((str[i]=='h')&&(str[i-1]=='z'))// one of Russian letters 
			{										//can be encoded in two ways: j & zh
				res += 'j';
				wait=false;
			}
			else if((str[i]=='u')&&(str[i-1]=='o'))// one of Russian letters 
			{										//can be encoded in two ways: u & ou
				res +='u';
				wait=false;
			}
			else if((str[i]=='s')&&(str[i-1]=='s'))// 's' can sometimes be doubled 
			{										// and sometimes not (Russian again)
				res +='s';
				wait=false;
			}
			else if((str[i]=='c')&&(str[i-1]=='t')&&(str.size()!=i+1)&&(str[i+1]=='h'))
			{								//tch = ch (Russian...)
				res +='c';
				wait=false;
			}
			else if((str[i]=='e')&&(str[i-1]=='\''))// another fancy Russian letter 
			{										//can be encoded as 'e, yo, and 
										//potentially many other yet undiscovered ways...
				res +="yo";
				wait=false;
			}
			else if((str[i]=='a')&&(str[i-1]=='y'))// another Russian letter of this type
			{										
				res +="ia";
				wait=false;
			}
			else if((str[i-1]=='\\')&&(str[i]=='l')) //latex fancy l (Polish)
			{
				res+='l';
				wait = false;
			}
			else if((str[i-1]=='\\')&&(str[i]=='o')) //latex fancy o (Norwegian)
			{
				res+='o';
				wait = false;
			}
			else if((str[i-1]=='\\')&&(str[i]=='i')) //latex fanci i (no idea which language)
			{
				res+='i';
				wait = false;
			}
			else if((str[i-1]=='\\')&&(str[i]=='L')) //latex fancy L (Polish)
			{
				res+='L';
				wait = false;
			}
			else if((str[i-1]=='\\')&&(str[i]=='O')) //latex fancy O (Norwegian)
			{
				res+='O';
				wait = false;
			}
			else if(str[i-1]=='\\') //accent or 2 letter tag
			{
				wait = false;
			}
			else
				res += str[i-1];
		}
		else
			wait = true;
	
	if(wait)
		res += str[i-1];

	int n = (int)res.size();
	if(n>2)
	{
		string suffix3 = res.substr(n-3,3);
		//-ski-sky-skiy-skij-skii are all converted to -ski
		if(!suffix3.compare("sky"))
		{
			res.erase(n-3,3);
			res += "ski";
		}
		//-in, -ine (different transcriptions of Russian last names in French and in English)
		if(!suffix3.compare("ine"))
			res.erase(n-1,1);
	}

	if(n>3)
	{
		string suffix4 = res.substr(n-4,4);
		//-ski-sky-skiy-skij-skii are all converted to -ski
		if(!suffix4.compare("skiy") || !suffix4.compare("skii") || !suffix4.compare("skij") )
		{
			res.erase(n-4,4);
			res += "ski";
		}
	}

	return res;
}

bool siGreater(SentInfo& si1, SentInfo& si2) 
{	
	if((int)si1.docids.size() != (int)si2.docids.size())
		return si1.docids.size() > si2.docids.size();
	if(si1.difAuN != si2.difAuN)
		return si1.difAuN > si2.difAuN;
	return si1.counter > si2.counter;	
}

void siarSort(siar& array)
{	sort(array.begin(),array.end(),siGreater);	}

bool sfLessDupFree(SimFiles& sf1, SimFiles& sf2)
{// compare two pairs of same-author similar papers by geometric mean of the percentage 
	//of their largest duplicate-free part. 

	double orig11 = sf1.dupfree1/sf1.filelen1;
	double orig12 = sf1.dupfree2/sf1.filelen2;

	double orig21 = sf2.dupfree1/sf2.filelen1;
	double orig22 = sf2.dupfree2/sf2.filelen2;

	double min1 = min(orig11,orig12);
	double min2 = min(orig21,orig22);
	double max1 = max(orig11,orig12);
	double max2 = max(orig21,orig22);

	if(min1 == min2)
		return max1 < max2;
	else
		return min1 < min2;
	
/*
	if((sf1.gmean == 0) && (sf2.gmean == 0))
	{//If one paper in each pair has 0 largest dup-free part, compare by largest dup-free
		// parts of the other papers

		int compVal1, compVal2; //non-zero largest dup-free parts
		if(sf1.dupfree1 == 0)
			compVal1 = sf1.dupfree2;
		else
			compVal1 = sf1.dupfree1;

		if(sf2.dupfree1 == 0)
			compVal2 = sf2.dupfree2;
		else
			compVal2 = sf2.dupfree1;
	
		return compVal1 < compVal2;
	}

	return sf1.gmean < sf2.gmean;
*/
}

bool sfGreaterDupNum(SimFiles& sf1, SimFiles& sf2)
{
	if(((sf1.priority == 1)||(sf2.priority==1))&&(sf1.priority != sf2.priority))
		return sf1.priority < sf2.priority;
	if(sf1.intrsen != sf2.intrsen)
		return sf1.intrsen > sf2.intrsen;
	return sf1.comsen > sf2.comsen;
}

void sfarSortDupFree(sfar& array)
{	sort(array.begin(),array.end(),sfLessDupFree);	}
void sfarSortDupNum(sfar& array)
{	sort(array.begin(),array.end(),sfGreaterDupNum);	}

//divide x by y and round correctly
int divround(int x, int y)
{
	double xd=x;
	double divd=xd/y;
	int divi=x/y;
	if(divd-divi < 0.5)
		return divi;
	else
		return divi+1;
}

string U64toString(U64 hash)
{
	char buf[512];
	U32 hash1 = (U32)(hash/0x100000000);
	U32 hash2 = (U32)hash;
	sprintf(buf,"%x %x ",hash1, hash2);
	string ret = buf;
	return ret;
}

//makes a list of files *.psv in all subdirectories;
//must not be used inside an important program; it causes strange reactions - 
//much better to use it to create an input file for the main program
void processFiles(const char *path_name, ofstream& fout)
{
	WIN32_FIND_DATA FN;
	HANDLE hFind;
	char search_arg[MAX_PATH], search_arg_psv[MAX_PATH], new_file_path[MAX_PATH];
	sprintf(search_arg, "%s\\*.*", path_name);
	sprintf(search_arg_psv, "%s\\*.psv", path_name);

	//find psv files
	hFind = FindFirstFile(search_arg_psv, &FN);
	if (hFind != INVALID_HANDLE_VALUE) 
	{
		do {
			sprintf(new_file_path, "%s\\%s", path_name, FN.cFileName);
			fout << new_file_path << endl;
		} while (FindNextFile(hFind, &FN) != 0);
		FindClose(&FN);
	}
	 
	//find directories
	hFind = FindFirstFile(search_arg, &FN);
	if (hFind != INVALID_HANDLE_VALUE) 
	{
		do {
			// Make sure that we don't process . or .. in FN.cFileName here.
			if (strcmp(FN.cFileName, ".") != 0 && strcmp(FN.cFileName, "..") != 0) 
			{
				sprintf(new_file_path, "%s\\%s", path_name, FN.cFileName);
				// If this is a directory then recurse into the directory
				if (FN.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
					processFiles(new_file_path,fout);
			}
		} while (FindNextFile(hFind, &FN) != 0);

		FindClose(&FN);
	}
}

bool isSuffix(string str)
{
	if(!str.compare("Jr") || !str.compare("jr") || 
		!str.compare("II") || !str.compare("III"))
		return true;
	return false;
}

void extrAuthor(const char* fname, stringv& authors, stringset& collaborations)
{
	char buf[256];//buffer to read data from file
// first part: read the whole abs file, search for known collaborations, add them as authors

	ifstream fin1; //stream associated with the file
	fin1.open(fname,ios_base::in);
	fin1.read(buf,256);

	string sequence;	//current word
	char prevc = '*';
	while(fin1.gcount())
	{   //process data from buf
		for(int c=0;c<fin1.gcount();c++)
		    //process character at buf[c]
			if(((buf[c]>='a')&&(buf[c]<='z')) || ((buf[c]>='A')&&(buf[c]<='Z')) ||
				((buf[c]>='0')&&(buf[c]<='9')) || (buf[c]=='`')	|| (buf[c]=='-') || 
				(buf[c]=='\\') || (buf[c]=='\"') || (buf[c]=='\'') || (buf[c]=='&') || 
				(buf[c]=='{') || (buf[c]=='}') || (buf[c]=='~') || 
				((buf[c]=='.')&& (prevc=='\\')))
			{
				sequence += buf[c];
				prevc = buf[c];
			}
			else if(!sequence.empty())
			{
				stringset::iterator strit = collaborations.find(sequence);
				if(strit != collaborations.end())
					if(!sequence.compare("CMD2"))
						authors.push_back("CMD-2 Collaboration");
					else if(!sequence.compare("SuperCDMS"))
						authors.push_back("CDMS Collaboration");
					else if(!sequence.compare("Super-Kamiokande"))
						authors.push_back("Kamiokande Collaboration");
					else if(!sequence.compare("D0"))
						authors.push_back("DZero Collaboration");
					else if(!sequence.compare("MiniBooNE"))
						authors.push_back("BooNe Collaboration");
					else if(!sequence.compare("BABAR"))
						authors.push_back("BaBar Collaboration");
					else
						authors.push_back(sequence + " Collaboration");

				sequence.resize(0);
				prevc = '*';
			}
		fin1.read(buf,256);
	}
	fin1.close();

// second part: extract authors from Author(s) field
	ifstream fin; //stream associated with the file
	fin.open(fname,ios_base::in);
	fin.read(buf,256);

	sequence="**";	//current word
	prevc='*';
	string previous="##";	//previous word
	string prev2="@@";		//prevprevious word
	string prev3="^^";		//...
	string prev4="&&";		//...
	string bracprev = "~~";	//previous when we are in brackets
	string bracprev2 = "$$";
	string bracseq = "!!!";	//sequence when we are in brackets
	bool started=false;
	int bropen=0;

	while(fin.gcount())
	{   //process data from buf
		for(int c=0;c<fin.gcount();c++)
		    //process character at buf[c]
			if(started && (bropen>0))
			{
				//the only goal inside parenthesis is to extract collaboration
				if(((buf[c]>='a')&&(buf[c]<='z')) || ((buf[c]>='A')&&(buf[c]<='Z')) ||
					((buf[c]>='0')&&(buf[c]<='9')) || (buf[c]=='`')	|| (buf[c]=='-') || 
					(buf[c]=='\\') || (buf[c]=='\"') || (buf[c]=='\'') || (buf[c]=='&') || 
					(buf[c]=='{') || (buf[c]=='}') || (buf[c]=='~') || 
					((buf[c]=='.')&& (prevc=='\\')))
				{
					bracseq += buf[c];
					prevc = buf[c];
				}

				else
				{
					if(!bracseq.empty())
					{
						if(!bracseq.compare("Collaboration") ||
							!bracseq.compare("collaboration") ||
							!bracseq.compare("collaborations") ||
							!bracseq.compare("Collaborations"))
							authors.push_back(bracprev + " Collaboration");
						
						if(!simpleNm(bracseq).compare(simpleNm("Group")) && 
							!simpleNm(bracprev).compare(simpleNm("Working")))
							authors.push_back(bracprev2 + " Collaboration");

						bracprev2=bracprev;
						bracprev=bracseq;
						bracseq.resize(0);
						prevc = '*';
					}
					if(buf[c]==')')
					{
						bropen--;
						bracprev = "#";
						bracprev2 = "$";
					}
					if(buf[c]=='(')
					{
						bropen++;
						bracprev = "#";
						bracprev2 = "$";
					}
				}
			}
			else if(((buf[c]>='a')&&(buf[c]<='z')) || ((buf[c]>='A')&&(buf[c]<='Z')) ||
					((buf[c]>='0')&&(buf[c]<='9')) || (buf[c]=='`')	|| (buf[c]=='-') || 
					(buf[c]=='\\') || (buf[c]=='\"') || (buf[c]=='\'') || (buf[c]=='&') || 
					(buf[c]=='{') || (buf[c]=='}') || (buf[c]=='~') || 
					((buf[c]=='.')&& (prevc=='\\')))
			{
				sequence += buf[c];
				prevc = buf[c];
			}
			else
			{
				if(!sequence.empty())
				{
					if(!started)
					{
						if(!sequence.compare("Author") || !sequence.compare("Authors"))
							started=true;
					}
					else
					{
						if(!sequence.compare("al") && !previous.compare("et") && (prev2.size() > 1)) //Someone et al
							if(!isSuffix(prev2))
								authors.push_back(prev2); //et al, no suffix, no backward initials
							else
								authors.push_back(prev3); //et al, suffix, no backward initials
						else if(!sequence.compare("etal"))
							if(!isSuffix(previous))
								authors.push_back(previous); //etal, no suffix, no backward initials
							else
								authors.push_back(prev2); //etal, suffix, no backward initials
			
						else if(!sequence.compare("Collaboration") ||
							!sequence.compare("collaboration") ||
							!sequence.compare("collaborations") ||
							!sequence.compare("Collaborations"))
							authors.push_back(previous + " Collaboration");
						else if(!simpleNm(sequence).compare(simpleNm("Group")) && 
							!simpleNm(previous).compare(simpleNm("Working")))
							authors.push_back(prev2 + " Collaboration");
						else if( !sequence.compare("Comments") || 
						    !sequence.compare("\\\\") ||
							!sequence.compare("Title") || 
							!sequence.compare("Subj-class") || 
							!sequence.compare("ACM-class") || 
							!sequence.compare("MSC-class") || 
							!sequence.compare("DOI") || 
							!sequence.compare("Report-no")	|| 
							!sequence.compare("Journal-ref") ||
							!sequence.compare("Categories") ||
							!sequence.compare("Proxy") ||
							!sequence.compare("and") ||
							!sequence.compare("&") ||
							!sequence.compare("for"))
						{
							if(previous.compare("Collaboration") &&
								previous.compare("collaboration") &&
								previous.compare("Collaborations") &&
								previous.compare("collaborations") &&
								(simpleNm(previous).compare(simpleNm("Group")) 
									|| simpleNm(prev2).compare(simpleNm("Working"))) &&
								(previous.compare("al") || prev2.compare("et")) &&
								previous.compare("etal")
								)
								
								if(previous.size() == 1) //initials after last name - I assume there will be no suffix in this case
									if(prev2.size() == 1)
										authors.push_back(prev3);
									else
										authors.push_back(prev2);
								else
									if(!isSuffix(previous))
										authors.push_back(previous);
									else
										authors.push_back(prev2);
							
							if( !sequence.compare("Comments") || 
							    !sequence.compare("\\\\") ||
								!sequence.compare("Subj-class") || 
								!sequence.compare("Title") || 
								!sequence.compare("ACM-class") || 
								!sequence.compare("MSC-class") || 
								!sequence.compare("DOI") || 
								!sequence.compare("Report-no")	|| 
								!sequence.compare("Categories")	|| 
								!sequence.compare("Journal-ref")||
								!sequence.compare("Proxy")
								)
							{
								fin.close();

								refineAuthors(authors);
								return;
							}
						}
						if(buf[c]==',')
						{
							if(sequence.compare("Collaboration") &&
								sequence.compare("collaboration") &&
								sequence.compare("Collaborations") &&
								sequence.compare("collaborations") &&
								(simpleNm(sequence).compare(simpleNm("Group"))
									|| simpleNm(previous).compare(simpleNm("Working"))) &&
								(sequence.compare("al") || previous.compare("et")) &&
								sequence.compare("etal")
								)
								
								if(sequence.size() == 1) //initials after last name
									if(previous.size() == 1)
										authors.push_back(prev2);
									else
										authors.push_back(previous);
								else
									if(!isSuffix(sequence))
										authors.push_back(sequence);
									else
										authors.push_back(previous);
						}
						prev4=prev3;
						prev3=prev2;
						prev2=previous;
						previous=sequence;

					}
					sequence.resize(0);
					prevc = '*';
				}
				if((started) && ((buf[c]=='(') || (buf[c]==',')))
				{
					if(buf[c]=='(')
					{
						bropen++;
						bracseq.resize(0);
					}
					if(previous.compare("Collaboration") &&
						previous.compare("collaboration") &&
						previous.compare("Collaborations") &&
						previous.compare("collaborations") &&
						(simpleNm(previous).compare(simpleNm("Group")) 
							|| simpleNm(prev2).compare(simpleNm("Working"))) &&
						(previous.compare("al") || prev2.compare("et")) &&
						previous.compare("etal")
						)
						
						if(previous.size() == 1) //initials after last name
							if(prev2.size() == 1)
								authors.push_back(prev3);
							else
								authors.push_back(prev2);
						else
							if(!isSuffix(previous))
								authors.push_back(previous);
							else
								authors.push_back(prev2);
				}
		}
		fin.read(buf,256);
	}
	fin.close();

	refineAuthors(authors);
}

void refineAuthors(stringv& authors)
{
	stringv au_copy = authors;
	//some postprocessing of author list
	for(stringv::iterator auit = authors.begin(); auit != authors.end(); )
		if(!(auit->compare("experiment")) || !(auit->compare("others")))
			auit = authors.erase(auit); //eliminate words that are definitely not authors
		else
			auit++;

	for(stringv::iterator auit = au_copy.begin(); auit != au_copy.end(); auit++)
	{ //break in two parts names with hyphen
		int n = (int)(auit->size());
		if((n<13) || auit->substr(n-13).compare("Collaboration"))
		{
			int hyphen = (int)auit->find('-');
			if(hyphen > 0)
			{
				authors.push_back(auit->substr(0,hyphen));
				authors.push_back(auit->substr(hyphen+1,n-hyphen-1));
			}
		}
	}
}

bool checkSwitch(const char* fname, hashset& authors)
{
	char buf[256];//buffer to read data from file
	ifstream fin; //stream associated with the file
	fin.open(fname,ios_base::in);
	fin.read(buf,256);

	string sequence="*";//current word
	string previous="#";//previous word
	string prev2="@";//prevprevious word
	bool started=false;


	while(fin.gcount())
	{   //process data from buf
		for(int c=0;c<fin.gcount();c++)
		    //process character at buf[c]
			if(((buf[c]>='a')&&(buf[c]<='z'))||((buf[c]>='A')&&(buf[c]<='Z'))||
					(buf[c]=='-') || (buf[c]=='\\') || (buf[c]=='\"') || (buf[c]=='\'') || 
					(buf[c]=='&') ||(buf[c]=='{') || (buf[c]=='}') || (buf[c]=='~'))
			{
				sequence += buf[c];
			}
			else
			{
				if(!sequence.empty())
				{
					if(!started)
					{
						if(!sequence.compare("Author") || !sequence.compare("Authors"))
							started=true;
					}
					else
					{
							
						if( !sequence.compare("Comments") || 
							!sequence.compare("\\\\") ||
							!sequence.compare("Subj-class") || 
							!sequence.compare("Title") || 
							!sequence.compare("ACM-class") || 
							!sequence.compare("MSC-class") || 
							!sequence.compare("DOI") || 
							!sequence.compare("Report-no")	|| 
							!sequence.compare("Categories")	|| 
							!sequence.compare("Journal-ref")||
							!sequence.compare("Proxy")
							)
						
							return false;

						if(authors.find(fingerprint(simpleNm(sequence)))!=authors.end())
							return true;
					}
					sequence.resize(0);
				}
		}
		fin.read(buf,256);
	}
	return false; //never to be reached
}

//return path to the abs file from the path to psv file
string psvToAbs(string psvstr)
{
	//X:\arXiv_data\txt\astro-ph\0001\0001001.txt
	//X:\arXiv_data\ftp\astro-ph\0001\0001001.abs

	int n=(int)psvstr.size();
	psvstr[n-3]='a';
	psvstr[n-2]='b';
	psvstr[n-1]='s';

	int slash = 0;
	for(int i=n-1; i>0; i--)
		if(psvstr[i] == '\\')
		{
			slash++;
			if(slash == 4)
				break;
		}

    psvstr[i+1]='f';
	psvstr[i+2]='t';
	psvstr[i+3]='p';
	
//	string ins("\\papers");
//	psvstr.insert(psvstr.begin() + n - 17,ins.begin(),ins.end());
	
	return psvstr;
}

//return short encoding for arxiv file from the path to psv file
string psvToShort(string psvstr)
{
	//X:\arXiv_data\txt\astro-ph\0001\0001001.psv
	//astro-ph/0001001

	string shortstr;

	int n=(int)psvstr.size();
	
	for(int slashNo = n-18; slashNo>=0; slashNo--)
		if(psvstr[slashNo] == '\\')
			break;

	shortstr = psvstr.substr(slashNo+1,n-18-slashNo);

/*	shortstr.resize(n-18-slashNo);
    for(int c=slashNo+1;c<n-17;c++)
		shortstr[c-slashNo-1] = psvstr[c];
*/
	shortstr += '/';
	shortstr += psvstr.substr(n-11,7);

	return shortstr;
}

//true if intersection of 2 sets is not zero excluding ignorestr
bool intersect(hashset& set1, hashset& set2)
{
	for(hashset::iterator setit=set1.begin();setit!=set1.end();setit++)
		if(set2.find(*setit) != set2.end())
			return true;

	return false;
}

//true if set1 contains set2
bool includes(hashset& set1, hashset& set2)
{
	for(hashset::iterator setit=set2.begin();setit!=set2.end();setit++)
		if(set1.find(*setit)==set1.end())
			return false;
	return true;
}

/*//returns set of k-grams following Winnowing algorithm, but smallest item is word, not symbol
hashset kgrams(string& sentence, int length)
{
	hashv allgrams; //all kgrams from this sentence
	hashset res;  //selected kgrams

	intv spaces; //places of word boundaries in the sentence
	//fill spaces
	spaces.push_back(0);
	for(int c=0; c<(int)sentence.size(); c++)
		if(sentence[c] == ' ')
			spaces.push_back(c);
	spaces.push_back((int)sentence.size()-1);
	
	//count all kgrams, fill allgrams
	for(int w=0; w < length-WINK+1; w++)
		allgrams.push_back(fingerprint(sentence.substr(spaces[w],spaces[w+WINK]-spaces[w])));

	if((int)allgrams.size() <= WINT)
	{
		sort(allgrams.begin(),allgrams.end());
		res.insert(allgrams[0]);
		return res;
	}
	
	//fill res, select 1 kgram from every window of size WINT
	for(int k=0; k < (int)allgrams.size() - WINT; k++)
	{
		hashv window; //content of window beginning with word k
		window.assign(allgrams.begin() + k, allgrams.begin() + k + WINT);
		sort(window.begin(),window.end());
		U64 best = window[0];//smallest kgram in window
		res.insert(best);
	}

	return res;
}
*/

//returns set of k-grams following Winnowing algorithm, but smallest item is word, not symbol
hashset kgrams(string& sentence, int length)
{
 hashv allgrams; //all kgrams from this sentence
 hashset res;  //selected kgrams
 intv spaces; //places of word boundaries in the sentence
 //fill spaces
 spaces.push_back(0);
 for(int c=0; c<(int)sentence.size(); c++)
  if(sentence[c] == ' ')
   spaces.push_back(c);
 spaces.push_back((int)sentence.size());
 
 //count all kgrams, fill allgrams
 for(int w=0; w < length-WINK+1; w++)
  allgrams.push_back(fingerprint(sentence.substr(spaces[w],spaces[w+WINK]-spaces[w])));
 if(length <= WINT)
 {
  sort(allgrams.begin(),allgrams.end());
  res.insert(allgrams[0]);
  return res;
 }
 
 //fill res, select 1 kgram from every window of size WINT
 for(int k=0; k <= length - WINT; k++)
 {
  hashv window; //content of window beginning with word k
  window.assign(allgrams.begin() + k, allgrams.begin() + k + WINT-WINK+1);
  sort(window.begin(),window.end());
  U64 best = window[0];//smallest kgram in window
  res.insert(best);
 }
 return res;
}

//finds part of sentence that was hashed in a given kgram(hash)
string findKGram(string& sentence, U64 hash)
{
	intv spaces; //places of word boundaries in the sentence
	//fill spaces
	spaces.push_back(0);
	for(int c=0; c<(int)sentence.size(); c++)
		if(sentence[c] == ' ')
			spaces.push_back(c);
	spaces.push_back((int)sentence.size()-1);

	//count kgrams one by one, find the required one
	for(int w=0; true; w++)
	{
		string subsen = sentence.substr(spaces[w],spaces[w+WINK]-spaces[w]);
		if(fingerprint(subsen) == hash)
			return subsen;
	}
}

//returns the number of the word where the kgram begins
int findPlaceKGram(string& sentence, U64 hash, int wordN)
{
	intv spaces; //places of word boundaries in the sentence
	//fill spaces
	spaces.push_back(0);
	for(int c=0; c<(int)sentence.size(); c++)
		if(sentence[c] == ' ')
			spaces.push_back(c);
	spaces.push_back((int)sentence.size()-1);

	//count kgrams one by one, find the required one
	for(int w=0; true; w++)
	{
		string subsen = sentence.substr(spaces[w],spaces[w+WINK]-spaces[w]);
		if(fingerprint(subsen) == hash)
			return w;
	}
}

//makes html output with hashes colored correctly
void colorSen(string& sentence, hashset& hashes1, hashset& hashes2, int wordN)
{
	hashset kgramset = kgrams(sentence, wordN);
	intv color(wordN,0); //0 - black or green or blue, 1 - red, 2 - magenta

	bool hasDup = false; //true, if the sentence contains duplicates
	bool hasComDup = false; //true, if the sentence contains common duplicates
	//fill color
	for(hashset::iterator kgit=kgramset.begin(); kgit != kgramset.end();kgit++)
		if( hashes1.find(*kgit) != hashes1.end() )
		{
			hasDup = true;
			int fw = findPlaceKGram(sentence,*kgit,wordN);
			for(int cw = 0; cw < WINK; cw++) 
				color[fw + cw]=1;
		}
		else if(hashes2.find(*kgit)!=hashes2.end())
		{
			hasComDup = true;
			int fw = findPlaceKGram(sentence,*kgit,wordN);
			for(int cw = 0; cw < WINK; cw++) 
				color[fw + cw]=2;
		}

	intv spaces; //places of word boundaries in the sentence
	//fill spaces
	spaces.push_back(0);
	for(int c=0; c<(int)sentence.size(); c++)
		if(sentence[c] == ' ')
			spaces.push_back(c);
	spaces.push_back((int)sentence.size()-1);


	string closetag("</font>");
	string brtag("<br>");
	string opentag[3];
	
	if(hasDup)
		opentag[0] = (string)("<font color=green>");
	else if(hasComDup)
		opentag[0] = (string)("<font color=blue>");
	else
		opentag[0] = (string)("<font color=black>");

	opentag[1] = (string)("<font color=red>");
	opentag[2] = (string)("<font color=magenta>");
	string nbsp("&nbsp;&nbsp;&nbsp;&nbsp;");
	
	//insert correspondent tags into the sentence
	for(int w=0; w<=wordN; w++)
	{
		//no tags between words of the same color
		if((w > 0) && (w < wordN) && (color[w-1] == color[w]))
			continue;
		
		//font closing tag after the last word of same color block
		if(w > 0)
		{
			sentence.insert(sentence.begin() + spaces[w], closetag.begin(), closetag.end());
			//positions of spaces have moved
			for(int sp=w; sp <= wordN; sp++)
				spaces[sp] += (int)closetag.size();
		}

		//line break tag in the end of sentence
		if(w == wordN)
			sentence.insert(sentence.end(), brtag.begin(), brtag.end());
		
		//font open tag (with name of color) before the first word of same color block 
		if(w < wordN)
		{
			sentence.insert(sentence.begin() + spaces[w], opentag[color[w]].begin(), 
							opentag[color[w]].end());
			//positions of spaces have moved
			for(int sp=w; sp <= wordN; sp++)
				spaces[sp] += (int)opentag[color[w]].size();
		}

		//spaces in the beginning of the sentence
		if(w == 0)
		{
			sentence.insert(sentence.begin() + spaces[w], nbsp.begin(), nbsp.end());
			for(int sp=w; sp <= wordN; sp++)
				spaces[sp] += (int)nbsp.size();
		}
	}
}

//converts file name to html link to arxive.org
//.\txt\cond-mat\0111\0111327.psv
//<a href="http://arxiv.org/abs/cond-mat/0111327">cond-mat/0111327</a>
string fnameToLink(string line)
{
	int lsize = (int)line.size();
	for(int c=6; line[c] != '\\' ;c++);
	string area = line.substr(6,c-6);
	string number = line.substr(lsize-11,7);
	area += "/";
	area += number;
	line = "<a href=\"http://arxiv.org/abs/";
	line += area;
	line += "\">";
	line +=	area;
	line += "</a>";

	return line;
}

//shortens file name to paper id
//.\txt\cond-mat\0111\0111327.psv
//cond-mat/0111327
string fnameToId(string line)
{
	int lsize = (int)line.size();
	for(int c=6; line[c] != '\\' ;c++);
	string area = line.substr(6,c-6);
	string number = line.substr(lsize-11,7);
	string id = area;
	id += "/";
	id += number;

	return id;
}

//outputs heights of bars in one line, values of x in the other line
void outHist(ofstream& fout, intmap& hist)
{
	for(intmap::iterator histIt = hist.begin();histIt != hist.end();histIt++)
		fout << histIt->second << " \t";
	fout << endl;
	for(intmap::iterator histIt = hist.begin();histIt != hist.end();histIt++)
		fout << histIt->first << " \t";
	fout << endl;
}

//inserts new value into the map or increases existing value
void updateMap(intmap& m, int key, int add)
{
	intmap::iterator mapIt = m.find(key);
	if(mapIt != m.end())
		mapIt->second += add;
	else
		m.insert(intmap::value_type(key, add));
}

//join two maps: sum values of identical keys, add all other
intmap joinMaps(intmap& map1, intmap& map2)
{
	intmap newMap = map1;
	for(intmap::iterator mapIt = map2.begin();mapIt != map2.end();mapIt++)
		updateMap(newMap, mapIt->first, mapIt->second);

	return newMap;
}

//convert values from map into histogram
intmap mapToHist(intmap& m)
{
	intmap hist;
	for(intmap::iterator mapIt = m.begin(); mapIt != m.end(); mapIt++)
		updateMap(hist,mapIt->second,1);

	return hist;
}