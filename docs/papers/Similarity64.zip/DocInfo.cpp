#include "StdAfx.h"
#include ".\docinfo.h"

DocInfo::DocInfo(void)
{
}

DocInfo::~DocInfo(void)
{
}
