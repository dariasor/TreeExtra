// Similarity.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "SimSearch.h"
#include "functions.h"
#include <fstream>
#include <windows.h>

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Is it OK to delete the contents of the folder \"similar\"? (y/n) \n";
	char inc;
	cin >> inc;

	if((inc != 'y') && (inc != 'Y'))
		return 0;

	cout << "Deleting... it make take a while...";
	//delete all files from the previous run 
	WIN32_FIND_DATA fn; //structure that will contain the name of file
	HANDLE hFind; //current file
	hFind = FindFirstFile(".\\similar\\*.*", &fn);
	
	FindNextFile(hFind, &fn);//skip "." and ".."
	FindNextFile(hFind, &fn);
	
	if (hFind != INVALID_HANDLE_VALUE) 
	{
		do {
			string fullName = "similar\\" + (string)fn.cFileName;
			DeleteFile(fullName.c_str());
		} while (FindNextFile(hFind, &fn) != 0);
	}

	cout << "   Done\n\n";

	cout << "Do you want to output all html results? (y/n, say n if you need graph only) ";
	cin >> inc;
	bool outHTML =	((inc == 'y') || (inc == 'Y'));


	CreateDirectory("similar",NULL);

//insert all files listed in files.txt, this file can be prepared with ListFile program

	SimSearch sim("psvfiles.txt");

//create simstat.txt (statistics) and simcommon.txt (most common sentences)
	ofstream fout2,foutStat;
	fout2.open("similar\\simcommon.txt",ios_base::out);

	int commonN;//number of common sentences
	sim.outStat(fout2,commonN); //output common sentences.
	fout2.close();	
	
//output all similar pairs of files & statistics
	
	int sameN,pureN,commentN;//numbers of pairs
	sim.outSimFiles(sameN,pureN,commentN, outHTML);

//create index.html
	ofstream fout0;
	fout0.open("similar\\index.html",ios_base::out);
	
// output links to different authors - pure pairs
	fout0 << "Similar files of of different authors - pure: " << pureN << " pairs<br>" 
		<< endl;
	for(int pageNum = 0; pageNum < (pureN-1)/PAGE_LEN; pageNum++)
		fout0 << " <a href=\"pure" << pageNum*PAGE_LEN + 1 << ".html\">" 
			<< pageNum*PAGE_LEN + 1 << "-" << (pageNum+1)*PAGE_LEN  << "</a> |";

	if(pureN)
		fout0 << " <a href=\"pure" << pageNum*PAGE_LEN + 1 << ".html\">" 
				<< pageNum*PAGE_LEN + 1 << "-" << pureN << "</a><br>" << endl;
	fout0 << "<br>" << endl;

// output links to different authors - commented pairs
	fout0 << "Similar files of different authors - with comments: " << commentN 
			<< " pairs<br>" << endl;
	for(pageNum = 0; pageNum < (commentN-1)/PAGE_LEN; pageNum++)
		fout0 << " <a href=\"comm" << pageNum*PAGE_LEN + 1 << ".html\">" 
			<< pageNum*PAGE_LEN + 1 << "-" << (pageNum+1)*PAGE_LEN  << "</a> |";

	if(commentN)
		fout0 << " <a href=\"comm" << pageNum*PAGE_LEN + 1 << ".html\">" 
				<< pageNum*PAGE_LEN + 1 << "-" << commentN << "</a><br>" << endl;
	fout0 << "<br>" << endl;

// output links to same authors pairs

	fout0 << "Similar files of the same authors: " << sameN << " pairs<br>" << endl;
	for(pageNum = 0; pageNum < (sameN-1)/PAGE_LEN; pageNum++)
		fout0 << " <a href=\"same" << pageNum*PAGE_LEN + 1 << ".html\">" 
			<< pageNum*PAGE_LEN + 1 << "-" << (pageNum+1)*PAGE_LEN << "</a> |";

	if(sameN)
		fout0 << " <a href=\"same" << pageNum*PAGE_LEN + 1 << ".html\">" 
				<< pageNum*PAGE_LEN + 1 << "-" << sameN << "</a><br>" << endl;
	fout0 << "<br>" << endl;

//output most common sentences and warnings

	fout0 << "<a href=\"simcommon.txt\"> Most common sentences</a>: " << commonN 
		<< " sentences<br>" << endl;
	fout0 << "<a href=\"warnings.html\"> Warnings about input data </a><br>" << endl;
	fout0.close();

	foutStat.open("similar\\simstat.txt",ios_base::out);
	foutStat << "coauthor heuristic: " << sim.coauFP << '\n';
	foutStat << "collaboration heuristic: " << sim.collFP << '\n';
	foutStat << "mentioned heuristic: " << sim.mentFP << '\n';
	foutStat << "referenced heuristic: " << sim.refFP << '\n';
	foutStat << "both mentioned and collaboration heuristic: " << sim.mcFP << '\n';
	foutStat << "switched first and last names heuristic: " << sim.switchFP << '\n';

	foutStat.close();

	ofstream plotpure, plotcomm, plotsame;
	plotpure.open("similar\\plotpure.txt",ios_base::out);
	plotcomm.open("similar\\plotcomm.txt",ios_base::out);
	plotsame.open("similar\\plotsame.txt",ios_base::out);

	for(intv::reverse_iterator psIt = sim.purestat.rbegin();psIt != sim.purestat.rend();psIt++)
		plotpure << *psIt << '\t';
	plotpure << '\n';
	plotpure.close();

	for(intv::reverse_iterator csIt = sim.commstat.rbegin();csIt != sim.commstat.rend();csIt++)
		plotcomm << *csIt << '\t';
	plotcomm << '\n';
	plotcomm.close();

	for(doublepv::iterator ssIt = sim.samestat.begin();ssIt != sim.samestat.end();ssIt++)
		plotsame << ssIt->first << '\t';
	plotsame << '\n';
	for(ssIt = sim.samestat.begin();ssIt != sim.samestat.end();ssIt++)
		plotsame << ssIt->second << '\t';
	plotsame << '\n';

	plotsame.close();


//	cout << "Ready to finish? ";
//	cin >> inc;
	return 0;
}

